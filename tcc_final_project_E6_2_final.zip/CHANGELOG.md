# CHANGELOG

All notable changes to this project will be documented in this file.

## [v1.0.0] - 2026-11-06
### Added
- Endpoint `POST /compare` (E5.5) returning `summary`, `results` (list[dict]), `histories` (list[dict]).
- Historical convergence data per seed (`histories`).
- Frontend `ComparisonPage` with cards, table, convergence chart and histogram, plus automatic state clearing on input changes.
- README updates: status Alternativa A, full contract example for `/compare`, execution instructions for backend and frontend.
- Scientific documentation (E5.4.7, E5.4.8) describing scope, mock irradiance and decision Alternativa A.
- Test suite expanded to 208 tests covering `/compare`, validation errors, retro‑compatibilidade (`/optimize`, `/baseline`).

### Fixed
- Stale results issue in `ComparisonPage` (now clears data when roof/config change and shows configuration banner).
- README outdated decision line (now correctly reflects Alternativa A).

### Deprecated
- None.

### Removed
- None.
